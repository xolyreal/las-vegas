// Las Vegas Roleplay — Discord.js v14 Components V2 Ticket System
// Install: npm install discord.js@14 dotenv
// Keep DISCORD_TOKEN and CLIENT_ID in .env. Never share that file.

require('dotenv').config();
const fs = require('node:fs');
const path = require('node:path');
const {
  ActionRowBuilder, AttachmentBuilder, ButtonBuilder, ButtonStyle,
  ChannelType, Client, ContainerBuilder, Events, GatewayIntentBits,
  MessageFlags, ModalBuilder, PermissionsBitField, REST, Routes,
  SeparatorBuilder, SlashCommandBuilder, StringSelectMenuBuilder,
  TextDisplayBuilder, TextInputBuilder, TextInputStyle
} = require('discord.js');

const CONFIG = {
  token: process.env.DISCORD_TOKEN,
  clientId: process.env.CLIENT_ID,
  guildId: '1566612734349414461',
  dashboardChannelId: '1566612735180152924',
  logsChannelId: '1566615470247776316',
  ticketCategoryId: '1566615572861550677',
  // IMPORTANT: replace any role ID that does not exist in your server.
  staffRoleIds: ['1566626718398288002', '1566626566216224819'],
  maxOpenTickets: 3,
  databaseFile: path.join(__dirname, 'ticket-state.json'),
  brand: 'LAS VEGAS ROLEPLAY',
  colors: { gold: 15105570, blue: 3447003, green: 5763719, red: 15158332, orange: 15105570 }
};

if (!CONFIG.token || !CONFIG.clientId) {
  console.error('Missing DISCORD_TOKEN or CLIENT_ID in .env.');
  process.exit(1);
}

const CATEGORIES = {
  general: { label: 'General Support', emoji: '💬', description: 'General questions and assistance.', prefix: 'general-support' },
  internal: { label: 'Internal Affairs', emoji: '⚖️', description: 'Player reports and rule violations.', prefix: 'internal-affairs' },
  management: { label: 'Management', emoji: '🏛️', description: 'Server issues and serious concerns.', prefix: 'management' }
};

const client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent, GatewayIntentBits.GuildMembers] });
const busyUsers = new Set();
const busyTickets = new Set();

function emptyDB() { return { nextTicketNumber: 1, dashboardMessageId: null, tickets: {} }; }
function loadDB() {
  try {
    if (!fs.existsSync(CONFIG.databaseFile)) return emptyDB();
    const d = JSON.parse(fs.readFileSync(CONFIG.databaseFile, 'utf8'));
    return { nextTicketNumber: Number(d.nextTicketNumber) || 1, dashboardMessageId: d.dashboardMessageId || null, tickets: d.tickets || {} };
  } catch (e) { console.error('Could not read ticket-state.json:', e); process.exit(1); }
}
let db = loadDB();
function saveDB() {
  const tmp = `${CONFIG.databaseFile}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(db, null, 2));
  fs.renameSync(tmp, CONFIG.databaseFile);
}
function getTicket(channelId) { return db.tickets[channelId] || null; }
function openCount(userId) { return Object.values(db.tickets).filter(t => t.creatorId === userId && t.status === 'open').length; }
function text(s) { return new TextDisplayBuilder().setContent(String(s)); }
function separator() { return new SeparatorBuilder().setSpacing(1).setDivider(true); }
function row(...items) { return new ActionRowBuilder().addComponents(items); }
function box(items, color = CONFIG.colors.gold) {
  const c = new ContainerBuilder().setAccentColor(color);
  for (const item of items) {
    if (item instanceof TextDisplayBuilder) c.addTextDisplayComponents(item);
    else if (item instanceof SeparatorBuilder) c.addSeparatorComponents(item);
    else c.addActionRowComponents(item);
  }
  return c;
}
function payload(components, ephemeral = false, extra = {}) {
  return { ...extra, flags: MessageFlags.IsComponentsV2 | (ephemeral ? MessageFlags.Ephemeral : 0), components };
}
function footer(label = 'OFFICIAL SUPPORT CENTER') { return `-# ${CONFIG.brand} • ${label}`; }
function info(title, body, color = CONFIG.colors.blue) { return box([text(`# ${title}\n${body}`), separator(), text(footer())], color); }
function ok(title, body) { return info(title, body, CONFIG.colors.green); }
function warn(title, body) { return info(title, body, CONFIG.colors.orange); }
function fail(title, body) { return info(title, body, CONFIG.colors.red); }
async function respond(interaction, component) {
  const p = payload([component], true);
  if (interaction.deferred || interaction.replied) return interaction.editReply(p);
  return interaction.reply(p);
}
async function replyError(i, title, body) { return respond(i, fail(title, body)); }
async function replySuccess(i, title, body) { return respond(i, ok(title, body)); }

async function fetchGuild() { return client.guilds.fetch(CONFIG.guildId); }
async function fetchStaffRoles(guild) {
  const roles = [];
  for (const id of CONFIG.staffRoleIds) {
    const role = await guild.roles.fetch(id).catch(() => null);
    if (role) roles.push(role);
    else console.error(`[CONFIG] Staff role ${id} was not found in guild ${guild.id}; it will not be granted ticket access.`);
  }
  return roles;
}
async function memberIsStaff(guild, userId) {
  const member = await guild.members.fetch(userId).catch(() => null);
  if (!member) return false;
  return member.permissions.has(PermissionsBitField.Flags.Administrator) || CONFIG.staffRoleIds.some(id => member.roles.cache.has(id));
}
function allowedUserMentions(userIds = [], roleIds = []) { return { parse: [], users: userIds, roles: roleIds }; }

// Dashboard
function buildDashboard() {
  const menu = new StringSelectMenuBuilder().setCustomId('ticket:category').setPlaceholder('Choose a support category...').setMinValues(1).setMaxValues(1)
    .addOptions(Object.entries(CATEGORIES).map(([value, c]) => ({ label: c.label, value, emoji: c.emoji, description: c.description })));
  return box([
    text('# Welcome to Las Vegas Roleplay\nWelcome to our community! We are glad to have you here. If you need assistance, our support team is ready to help.'),
    separator(),
    text('## Support Categories\n> **💬 General Support**\n> Questions, general assistance, and server information.\n\n> **⚖️ Internal Affairs**\n> Player reports, misconduct, and rule violations.\n\n> **🏛️ Management**\n> Server issues and serious management concerns.'),
    text('## Before Opening a Ticket\n- Choose the category that best matches your concern.\n- Explain your situation clearly and provide relevant details.\n- Be respectful toward the support team.\n- You may have a maximum of **3 open tickets** at a time.'),
    separator(),
    text('## Need Assistance?\nSelect a category below. You will be asked for a subject and details before your private ticket is created.'),
    row(menu),
    text(footer('OFFICIAL COMMUNITY'))
  ], CONFIG.colors.gold);
}
async function ensureDashboard() {
  const guild = await fetchGuild();
  const channel = await guild.channels.fetch(CONFIG.dashboardChannelId);
  if (!channel || !channel.isTextBased() || !channel.messages) throw new Error('Dashboard channel was not found or is not a text channel.');
  const p = payload([buildDashboard()]);
  if (db.dashboardMessageId) {
    const old = await channel.messages.fetch(db.dashboardMessageId).catch(() => null);
    if (old) { await old.edit(p); return; }
    db.dashboardMessageId = null; saveDB();
  }
  const message = await channel.send(p);
  db.dashboardMessageId = message.id; saveDB();
  console.log('Ticket dashboard created:', message.id);
}

// Logs
async function logEvent(title, details, color = CONFIG.colors.blue, files = []) {
  try {
    const channel = await client.channels.fetch(CONFIG.logsChannelId);
    if (!channel || !channel.isTextBased()) throw new Error('Logs channel is unavailable.');
    return await channel.send({ ...payload([box([text(`# ${title}`), separator(), text(details), separator(), text(footer('TICKET SYSTEM LOGS'))], color)]), files, allowedMentions: { parse: [] } });
  } catch (e) { console.error('Ticket log failed:', e); return null; }
}

// Ticket panels
function buildOpenPanel(t, mentionLine = null) {
  const category = CATEGORIES[t.category];
  const claim = new ButtonBuilder().setCustomId(`ticket:claim:${t.channelId}`).setLabel(t.claimedBy ? 'Unclaim Ticket' : 'Claim Ticket').setEmoji(t.claimedBy ? '↩️' : '🙋').setStyle(t.claimedBy ? ButtonStyle.Secondary : ButtonStyle.Primary);
  const close = new ButtonBuilder().setCustomId(`ticket:close:${t.channelId}`).setLabel('Close Ticket').setEmoji('🔒').setStyle(ButtonStyle.Danger);
  return box([
    ...(mentionLine ? [text(mentionLine)] : []),
    text('# Las Vegas Roleplay\nWelcome to your support ticket. Our team will review your request.'), separator(),
    text(`## Ticket Information\n> **Ticket:** #${t.ticketNumber}\n> **Category:** ${category.emoji} ${category.label}\n> **Customer:** <@${t.creatorId}>\n> **Created:** <t:${Math.floor(t.createdAt / 1000)}:F>\n> **Status:** 🟢 Open\n> **Assigned Staff:** ${t.claimedBy ? `<@${t.claimedBy}>` : 'Not yet claimed'}`),
    separator(), text(`## Subject\n${t.subject}`), text(`## Request Details\n${t.details}`), separator(),
    text('## Ticket Controls\nA staff member can claim this ticket. The ticket creator or an authorized staff member may request closure.'),
    row(claim, close), text(footer('SUPPORT DEPARTMENT'))
  ], t.claimedBy ? CONFIG.colors.green : CONFIG.colors.blue);
}
function buildClosedPanel(t) {
  const del = new ButtonBuilder().setCustomId(`ticket:delete:${t.channelId}`).setLabel('Delete Ticket').setEmoji('🗑️').setStyle(ButtonStyle.Danger);
  return box([
    text('# Ticket Closed\nThis ticket has been closed and is now read-only.'), separator(),
    text(`## Ticket Information\n> **Ticket:** #${t.ticketNumber}\n> **Customer:** <@${t.creatorId}>\n> **Category:** ${CATEGORIES[t.category]?.label || t.category}\n> **Status:** 🔴 Closed`), separator(),
    text(`## Closure Information\n> **Closed By:** <@${t.closedBy}>\n> **Closed:** <t:${Math.floor(t.closedAt / 1000)}:F>\n> **Transcript:** ${t.transcriptArchived ? 'Archived successfully' : 'Not archived'}`), separator(),
    text('## Ticket Controls\nThis ticket cannot be reopened. Staff may permanently delete it once its transcript has been archived.'),
    ...(t.transcriptArchived ? [row(del)] : []), text(footer('ARCHIVED TICKET'))
  ], CONFIG.colors.red);
}
async function updateTicketPanel(t) {
  if (!t.panelMessageId) return;
  try {
    const channel = await client.channels.fetch(t.channelId);
    if (!channel || !channel.messages) return;
    const message = await channel.messages.fetch(t.panelMessageId);
    await message.edit(payload([t.status === 'closed' ? buildClosedPanel(t) : buildOpenPanel(t)]));
  } catch (e) { console.error('Could not update ticket panel:', e); }
}

// Ticket modal and creation
function buildTicketModal(key) {
  const c = CATEGORIES[key];
  const subject = new TextInputBuilder().setCustomId('ticket_subject').setLabel('What is your ticket about?').setPlaceholder('Enter a short subject...').setStyle(TextInputStyle.Short).setMaxLength(100).setRequired(true);
  const details = new TextInputBuilder().setCustomId('ticket_details').setLabel('Please explain your situation').setPlaceholder('Provide all relevant information...').setStyle(TextInputStyle.Paragraph).setMaxLength(1500).setRequired(true);
  return new ModalBuilder().setCustomId(`ticket:submit:${key}`).setTitle(`${c.label} Ticket`).addComponents(row(subject), row(details));
}
async function createTicket(interaction, key) {
  const category = CATEGORIES[key];
  if (!category) return replyError(interaction, 'Invalid Category', 'Please select a valid support category.');
  const userId = interaction.user.id;
  if (busyUsers.has(userId)) return replyError(interaction, 'Please Wait', 'Your ticket is already being created. Please wait a moment.');
  if (openCount(userId) >= CONFIG.maxOpenTickets) return replyError(interaction, 'Ticket Limit Reached', `You already have ${CONFIG.maxOpenTickets} open tickets. Close an existing ticket before creating another.`);

  busyUsers.add(userId);
  await interaction.deferReply({ flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 });
  let createdChannel = null;
  try {
    const subject = interaction.fields.getTextInputValue('ticket_subject').trim();
    const details = interaction.fields.getTextInputValue('ticket_details').trim();
    if (!subject || !details) return replyError(interaction, 'Missing Information', 'Both the subject and details are required.');
    if (openCount(userId) >= CONFIG.maxOpenTickets) return replyError(interaction, 'Ticket Limit Reached', 'You have reached the maximum number of open tickets.');

    const guild = await fetchGuild();
    const [creator, botMember, parent] = await Promise.all([
      guild.members.fetch(userId),
      guild.members.fetch(client.user.id),
      guild.channels.fetch(CONFIG.ticketCategoryId)
    ]);
    if (!parent || parent.type !== ChannelType.GuildCategory) throw new Error('The configured ticket category is missing or is not a category channel.');
    const staffRoles = await fetchStaffRoles(guild);
    if (staffRoles.length === 0) throw new Error('No valid staff roles were found. Check CONFIG.staffRoleIds and copy the role IDs again from Server Settings > Roles.');

    const ticketNumber = db.nextTicketNumber++;
    saveDB();
    const overwrites = [
      { id: guild.roles.everyone, deny: [PermissionsBitField.Flags.ViewChannel] },
      { id: creator.user, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ReadMessageHistory, PermissionsBitField.Flags.AttachFiles, PermissionsBitField.Flags.EmbedLinks] },
      { id: botMember.user, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ReadMessageHistory, PermissionsBitField.Flags.ManageChannels, PermissionsBitField.Flags.AttachFiles, PermissionsBitField.Flags.EmbedLinks] },
      ...staffRoles.map(role => ({ id: role, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ReadMessageHistory, PermissionsBitField.Flags.AttachFiles, PermissionsBitField.Flags.EmbedLinks] }))
    ];

    createdChannel = await guild.channels.create({
      name: `${category.prefix}-${ticketNumber}`,
      type: ChannelType.GuildText,
      parent: parent.id,
      permissionOverwrites: overwrites,
      reason: `Support ticket #${ticketNumber} opened by ${interaction.user.tag}`
    });

    const ticket = {
      ticketNumber, channelId: createdChannel.id, creatorId: userId, category: key, subject, details,
      status: 'open', createdAt: Date.now(), claimedBy: null, addedMembers: [], panelMessageId: null,
      closedBy: null, closedAt: null, transcriptArchived: false, transcriptMessageId: null,
      transcriptFileName: null, transcriptDMStatus: 'not-sent', deletedAt: null, deletedBy: null,
      channelMissing: false
    };
    db.tickets[createdChannel.id] = ticket;
    saveDB();

    // Components V2 cannot include message.content. Put all mentions in a Text Display component.
    const mentions = `${interaction.user} ${staffRoles.map(r => `<@&${r.id}>`).join(' ')}`;
    const openingMessage = await createdChannel.send({
      ...payload([buildOpenPanel(ticket, mentions)]),
      allowedMentions: allowedUserMentions([userId], staffRoles.map(r => r.id))
    });
    ticket.panelMessageId = openingMessage.id;
    saveDB();

    await logEvent('Ticket Created', `## Ticket Information\n> **Ticket:** #${ticket.ticketNumber}\n> **Customer:** <@${userId}>\n> **Category:** ${category.emoji} ${category.label}\n> **Subject:** ${subject}\n> **Channel:** <#${createdChannel.id}>\n> **Created:** <t:${Math.floor(ticket.createdAt / 1000)}:F>`, CONFIG.colors.green);
    return replySuccess(interaction, 'Ticket Created', `Your **${category.label}** ticket has been created.\n\n> **Ticket:** #${ticketNumber}\n> **Channel:** <#${createdChannel.id}>\n\nUse the channel link to access your private ticket.`);
  } catch (error) {
    console.error('Ticket creation failed:', error);
    if (createdChannel) {
      delete db.tickets[createdChannel.id];
      saveDB();
      await createdChannel.delete('Rolling back incomplete ticket creation').catch(() => {});
    }
    return replyError(interaction, 'Ticket Could Not Be Created', `Discord could not create your ticket. Please contact staff if this continues.\n\n**Technical detail:** ${String(error.message || error).slice(0, 700)}`);
  } finally {
    busyUsers.delete(userId);
  }
}

// Claim / unclaim
async function handleClaim(i, t) {
  if (t.status !== 'open') return replyError(i, 'Ticket Closed', 'This ticket is no longer open.');
  if (!(await memberIsStaff(i.guild, i.user.id))) return replyError(i, 'Staff Only', 'Only authorized staff members can claim tickets.');
  if (!t.claimedBy) t.claimedBy = i.user.id;
  else if (t.claimedBy === i.user.id) t.claimedBy = null;
  else return replyError(i, 'Already Claimed', `This ticket is already claimed by <@${t.claimedBy}>.`);
  saveDB(); await updateTicketPanel(t);
  await logEvent(t.claimedBy ? 'Ticket Claimed' : 'Ticket Unclaimed', `> **Ticket:** #${t.ticketNumber}\n> **Channel:** <#${t.channelId}>\n> **Staff:** <@${i.user.id}>`, t.claimedBy ? CONFIG.colors.green : CONFIG.colors.orange);
  return replySuccess(i, t.claimedBy ? 'Ticket Claimed' : 'Ticket Unclaimed', t.claimedBy ? `You are now responsible for ticket #${t.ticketNumber}.` : `You have unclaimed ticket #${t.ticketNumber}.`);
}

// Add/remove members
async function manageTicketMember(i, action) {
  if (!(await memberIsStaff(i.guild, i.user.id))) return replyError(i, 'Staff Only', 'Only authorized staff members can manage ticket access.');
  const t = getTicket(i.channelId);
  if (!t || t.status !== 'open') return replyError(i, 'Invalid Ticket', 'This command can only be used inside an open ticket.');
  const target = i.options.getUser('user', true);
  if (target.bot) return replyError(i, 'Invalid Member', 'Bots cannot be added to or removed from tickets.');
  if (target.id === t.creatorId) return replyError(i, 'Ticket Creator', 'The ticket creator cannot be removed or modified.');
  const guild = i.guild;
  const member = await guild.members.fetch(target.id).catch(() => null);
  if (!member) return replyError(i, 'Member Not Found', 'That user is not a member of this server.');
  const staffRoles = await fetchStaffRoles(guild);
  const hasStaffRole = staffRoles.some(role => member.roles.cache.has(role.id));
  const channel = i.channel;
  if (action === 'add') {
    if (hasStaffRole) return replyError(i, 'Already Has Access', 'This member already has access through a staff role.');
    if ((t.addedMembers || []).includes(target.id)) return replyError(i, 'Already Added', 'This member already has access to this ticket.');
    await channel.permissionOverwrites.edit(member.user, { ViewChannel: true, SendMessages: true, ReadMessageHistory: true, AttachFiles: true, EmbedLinks: true });
    t.addedMembers.push(target.id);
  } else {
    if (hasStaffRole) return replyError(i, 'Staff Access', 'This member has access through a staff role and cannot be removed from the ticket.');
    if (!(t.addedMembers || []).includes(target.id)) return replyError(i, 'Not Added', 'This member was not added to this ticket.');
    await channel.permissionOverwrites.delete(member.user);
    t.addedMembers = t.addedMembers.filter(id => id !== target.id);
  }
  saveDB();
  await channel.send(payload([info(action === 'add' ? 'Member Added' : 'Member Removed', `<@${target.id}> has been ${action === 'add' ? 'given access to' : 'removed from'} this ticket.`, action === 'add' ? CONFIG.colors.green : CONFIG.colors.orange)]));
  await logEvent(action === 'add' ? 'Member Added to Ticket' : 'Member Removed from Ticket', `> **Ticket:** #${t.ticketNumber}\n> **Member:** <@${target.id}>\n> **Changed By:** <@${i.user.id}>\n> **Channel:** <#${t.channelId}>`, action === 'add' ? CONFIG.colors.green : CONFIG.colors.orange);
  return replySuccess(i, action === 'add' ? 'Member Added' : 'Member Removed', `<@${target.id}> ${action === 'add' ? 'can now access' : 'no longer has access to'} this ticket.`);
}

// HTML transcript
function esc(v = '') { return String(v).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[c])); }
function transcriptMessage(m) {
  const author = esc(m.author?.tag || 'Unknown User');
  const avatar = esc(m.author?.displayAvatarURL({ extension: 'png', size: 64 }) || '');
  const timestamp = esc(m.createdAt.toLocaleString());
  const content = esc(m.content || '').replace(/\n/g, '<br>');
  const attachments = [...m.attachments.values()].map(a => `<div class="attachment">📎 <a href="${esc(a.url)}" target="_blank" rel="noopener">${esc(a.name || 'Attachment')}</a></div>`).join('');
  const embeds = m.embeds.map(e => {
    const title = esc(e.title || ''); const desc = esc(e.description || '').replace(/\n/g, '<br>');
    const fields = (e.fields || []).map(f => `<p><strong>${esc(f.name)}</strong><br>${esc(f.value)}</p>`).join('');
    const image = e.image?.url ? `<p><a href="${esc(e.image.url)}" target="_blank" rel="noopener">Open embed image</a></p>` : '';
    return `<div class="embed">${title ? `<h4>${title}</h4>` : ''}${desc ? `<p>${desc}</p>` : ''}${fields}${image}</div>`;
  }).join('');
  return `<article class="message"><img class="avatar" src="${avatar}" alt=""><div class="body"><div class="head"><strong>${author}</strong><time>${timestamp}</time></div><div>${content || '<em>No text content</em>'}</div>${attachments}${embeds}</div></article>`;
}
async function fetchAllMessages(channel) {
  const all = []; let before;
  while (true) {
    const batch = await channel.messages.fetch({ limit: 100, ...(before ? { before } : {}) });
    if (!batch.size) break;
    all.push(...batch.values()); before = batch.last().id;
    if (batch.size < 100) break;
  }
  return all.sort((a, b) => a.createdTimestamp - b.createdTimestamp);
}
async function makeTranscript(t, channel) {
  const messages = await fetchAllMessages(channel);
  const body = messages.map(transcriptMessage).join('\n');
  const category = CATEGORIES[t.category]?.label || t.category;
  const html = `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Ticket #${t.ticketNumber} Transcript</title><style>*{box-sizing:border-box}body{margin:0;padding:30px 14px;background:#1e1f22;color:#dbdee1;font:15px Arial,sans-serif}.container{max-width:950px;margin:auto;background:#2b2d31;border-radius:12px;overflow:hidden}.header,.footer{padding:24px;background:#232428}.header h1{color:#fff}.header p{margin:7px 0;color:#b5bac1}.messages{padding:18px}.message{display:flex;gap:13px;padding:15px 4px;border-bottom:1px solid #3f4147}.avatar{width:42px;height:42px;border-radius:50%;background:#404249}.body{flex:1;min-width:0;overflow-wrap:anywhere}.head{display:flex;gap:12px;flex-wrap:wrap;margin-bottom:7px}.head strong{color:#fff}.head time{font-size:12px;color:#949ba4}.attachment{margin-top:9px}a{color:#00a8fc;text-decoration:none}.embed{margin-top:12px;padding:12px 15px;background:#232428;border-left:4px solid #5865f2;border-radius:4px}.embed h4{margin:0 0 8px;color:#fff}.footer{text-align:center;color:#949ba4;font-size:12px}</style></head><body><div class="container"><header class="header"><h1>Las Vegas Roleplay — Ticket Transcript</h1><p><b>Ticket:</b> #${t.ticketNumber}</p><p><b>Category:</b> ${esc(category)}</p><p><b>Subject:</b> ${esc(t.subject)}</p><p><b>Creator ID:</b> ${esc(t.creatorId)}</p><p><b>Created:</b> ${new Date(t.createdAt).toLocaleString()}</p><p><b>Closed:</b> ${new Date(t.closedAt || Date.now()).toLocaleString()}</p><p><b>Closed by ID:</b> ${esc(t.closedBy || 'Unknown')}</p><p><b>Messages:</b> ${messages.length}</p></header><main class="messages">${body}</main><footer class="footer">LAS VEGAS ROLEPLAY • OFFICIAL TICKET TRANSCRIPT</footer></div></body></html>`;
  return { buffer: Buffer.from(html, 'utf8'), fileName: `ticket-${t.ticketNumber}-transcript.html`, messageCount: messages.length };
}

// Close ticket
function closeConfirmation(channelId) {
  const yes = new ButtonBuilder().setCustomId(`ticket:confirm-close:${channelId}`).setLabel('Confirm Closure').setEmoji('✅').setStyle(ButtonStyle.Danger);
  const no = new ButtonBuilder().setCustomId(`ticket:cancel-close:${channelId}`).setLabel('Cancel').setEmoji('❌').setStyle(ButtonStyle.Secondary);
  return box([text('# Close Ticket\nAre you sure you want to close this ticket?'), separator(), text('## What Happens Next\n- An HTML transcript will be generated.\n- The transcript will be archived in the logs channel.\n- The ticket will become read-only.\n- The customer will receive the transcript by DM only after a successful archive.\n\n**This action cannot be reversed.**'), row(yes, no), text(footer('TICKET CLOSURE'))], CONFIG.colors.orange);
}
async function lockTicket(channel, t, guild) {
  const creator = await guild.members.fetch(t.creatorId).catch(() => null);
  if (creator) await channel.permissionOverwrites.edit(creator.user, { SendMessages: false, AddReactions: false, SendMessagesInThreads: false, CreatePublicThreads: false, CreatePrivateThreads: false });
  for (const id of (t.addedMembers || [])) {
    const member = await guild.members.fetch(id).catch(() => null);
    if (member) await channel.permissionOverwrites.edit(member.user, { SendMessages: false, AddReactions: false, SendMessagesInThreads: false, CreatePublicThreads: false, CreatePrivateThreads: false });
  }
  for (const role of await fetchStaffRoles(guild)) await channel.permissionOverwrites.edit(role, { SendMessages: false, AddReactions: false, SendMessagesInThreads: false, CreatePublicThreads: false, CreatePrivateThreads: false });
}
async function closeTicket(i, t) {
  if (t.status !== 'open') return replyError(i, 'Already Closed', 'This ticket has already been closed.');
  if (i.user.id !== t.creatorId && !(await memberIsStaff(i.guild, i.user.id))) return replyError(i, 'No Permission', 'Only the ticket creator or authorized staff may close this ticket.');
  const channel = await client.channels.fetch(t.channelId).catch(() => null);
  if (!channel || !channel.isTextBased()) return replyError(i, 'Ticket Not Found', 'The ticket channel could not be found.');
  t.closing = true; t.closedBy = i.user.id; t.closedAt = Date.now(); saveDB();
  let transcript;
  try { transcript = await makeTranscript(t, channel); }
  catch (e) { t.closing = false; t.closedBy = null; t.closedAt = null; saveDB(); console.error('Transcript generation failed:', e); return replyError(i, 'Transcript Failed', 'The transcript could not be generated. The ticket remains open.'); }
  let archived;
  try {
    const logs = await client.channels.fetch(CONFIG.logsChannelId);
    if (!logs || !logs.isTextBased()) throw new Error('Logs channel is unavailable.');
    archived = await logs.send({ ...payload([box([text('# Transcript Archived'), separator(), text(`## Ticket Information\n> **Ticket:** #${t.ticketNumber}\n> **Customer:** <@${t.creatorId}>\n> **Category:** ${CATEGORIES[t.category].label}\n> **Subject:** ${t.subject}\n> **Closed By:** <@${t.closedBy}>\n> **Messages:** ${transcript.messageCount}\n> **Channel ID:** ${t.channelId}`), separator(), text('The HTML transcript is attached to this archive entry.'), text(footer('TRANSCRIPT ARCHIVE'))], CONFIG.colors.green)]), files: [new AttachmentBuilder(transcript.buffer, { name: transcript.fileName })], allowedMentions: { parse: [] } });
    t.transcriptArchived = true; t.transcriptMessageId = archived.id; t.transcriptFileName = transcript.fileName; saveDB();
  } catch (e) { t.closing = false; t.closedBy = null; t.closedAt = null; saveDB(); console.error('Transcript archive failed:', e); return replyError(i, 'Transcript Archive Failed', 'The transcript could not be uploaded to the logs channel. The ticket remains open.'); }
  t.status = 'closed'; t.closing = false; saveDB();
  try { await lockTicket(channel, t, i.guild); } catch (e) { console.error('Ticket permission lock failed:', e); await logEvent('Ticket Lock Warning', `Ticket #${t.ticketNumber} was archived, but some read-only permissions may not have applied. Check bot permissions.`, CONFIG.colors.orange); }
  await updateTicketPanel(t);
  await channel.send(payload([info('Ticket Closed', `This ticket has been closed by <@${t.closedBy}>. The conversation is now read-only and the transcript has been archived.`, CONFIG.colors.red)]));
  await logEvent('Ticket Closed', `> **Ticket:** #${t.ticketNumber}\n> **Customer:** <@${t.creatorId}>\n> **Closed By:** <@${t.closedBy}>\n> **Channel:** <#${t.channelId}>\n> **Transcript:** Archived\n> **Archive:** ${archived.url}`, CONFIG.colors.red);
  // At-most-once delivery attempt prevents duplicate transcript DMs after a restart.
  if (!t.transcriptDMStatus || t.transcriptDMStatus === 'not-sent') {
    t.transcriptDMStatus = 'sending'; saveDB();
    try {
      const customer = await client.users.fetch(t.creatorId);
      await customer.send({ ...payload([info('Your Ticket Has Been Closed', `Your Las Vegas Roleplay ticket **#${t.ticketNumber}** has been closed. Your HTML transcript is attached below.`, CONFIG.colors.blue)]), files: [new AttachmentBuilder(transcript.buffer, { name: transcript.fileName })], allowedMentions: { parse: [] } });
      t.transcriptDMStatus = 'sent'; saveDB();
      await logEvent('Transcript DM Sent', `> **Ticket:** #${t.ticketNumber}\n> **Customer:** <@${t.creatorId}>\n> **Status:** Successfully delivered`, CONFIG.colors.green);
    } catch (e) {
      t.transcriptDMStatus = 'failed'; saveDB();
      await logEvent('Transcript DM Failed', `> **Ticket:** #${t.ticketNumber}\n> **Customer:** <@${t.creatorId}>\n> **Reason:** ${String(e.message || e).slice(0, 500)}\n> **Status:** Ticket closure remains successful`, CONFIG.colors.orange);
    }
  }
  return replySuccess(i, 'Ticket Closed', `Ticket #${t.ticketNumber} has been closed. Its HTML transcript is archived in the logs channel.`);
}

// Delete ticket
function deleteConfirmation(channelId) {
  const yes = new ButtonBuilder().setCustomId(`ticket:confirm-delete:${channelId}`).setLabel('Delete Ticket').setEmoji('🗑️').setStyle(ButtonStyle.Danger);
  const no = new ButtonBuilder().setCustomId(`ticket:cancel-delete:${channelId}`).setLabel('Cancel').setEmoji('❌').setStyle(ButtonStyle.Secondary);
  return box([text('# Delete Ticket\nYou are about to permanently delete this ticket channel.'), separator(), text('## Before You Continue\n- The ticket must already be closed.\n- The HTML transcript must already be archived.\n- The ticket channel will be permanently deleted.\n- No additional DM will be sent.\n\n**This action cannot be undone.**'), row(yes, no), text(footer('TICKET DELETION'))], CONFIG.colors.red);
}
async function deleteTicket(i, t) {
  if (!(await memberIsStaff(i.guild, i.user.id))) return replyError(i, 'Staff Only', 'Only authorized staff members can delete tickets.');
  if (t.status !== 'closed' || !t.transcriptArchived || !t.transcriptMessageId) return replyError(i, 'Cannot Delete', 'The ticket must be closed and its transcript archived first.');
  const channel = await client.channels.fetch(t.channelId).catch(() => null);
  if (!channel) { t.status = 'deleted'; t.channelMissing = true; t.deletedAt = Date.now(); t.deletedBy = i.user.id; saveDB(); return replyError(i, 'Channel Not Found', 'The channel no longer exists. Its record has been marked deleted.'); }
  t.status = 'deleting'; t.deletedBy = i.user.id; saveDB();
  try {
    await channel.delete(`Ticket #${t.ticketNumber} deleted by ${i.user.tag}`);
    t.status = 'deleted'; t.deletedAt = Date.now(); t.channelMissing = false; saveDB();
    await logEvent('Ticket Deleted', `> **Ticket:** #${t.ticketNumber}\n> **Deleted By:** <@${i.user.id}>\n> **Transcript:** Previously archived`, CONFIG.colors.red);
    return replySuccess(i, 'Ticket Deleted', `Ticket #${t.ticketNumber} has been permanently deleted.`);
  } catch (e) { t.status = 'closed'; saveDB(); console.error('Ticket deletion failed:', e); return replyError(i, 'Deletion Failed', 'Discord could not delete the ticket channel. Check the bot has Manage Channels permission.'); }
}

// Slash commands
const commands = [
  new SlashCommandBuilder().setName('ticket-add').setDescription('Add a member to the current ticket.').addUserOption(o => o.setName('user').setDescription('The member to add.').setRequired(true)),
  new SlashCommandBuilder().setName('ticket-remove').setDescription('Remove a member from the current ticket.').addUserOption(o => o.setName('user').setDescription('The member to remove.').setRequired(true))
].map(c => c.toJSON());
async function registerCommands() {
  const rest = new REST({ version: '10' }).setToken(CONFIG.token);
  await rest.put(Routes.applicationGuildCommands(CONFIG.clientId, CONFIG.guildId), { body: commands });
  console.log('Ticket slash commands registered.');
}

// Interaction router
client.on(Events.InteractionCreate, async i => {
  try {
    if (i.isStringSelectMenu() && i.customId === 'ticket:category') {
      const key = i.values[0];
      if (!CATEGORIES[key]) return replyError(i, 'Invalid Category', 'Please choose a valid category.');
      if (openCount(i.user.id) >= CONFIG.maxOpenTickets) return replyError(i, 'Ticket Limit Reached', `You may only have ${CONFIG.maxOpenTickets} open tickets at once.`);
      return i.showModal(buildTicketModal(key));
    }
    if (i.isModalSubmit() && i.customId.startsWith('ticket:submit:')) return createTicket(i, i.customId.split(':')[2]);
    if (i.isChatInputCommand()) {
      if (i.commandName === 'ticket-add') return manageTicketMember(i, 'add');
      if (i.commandName === 'ticket-remove') return manageTicketMember(i, 'remove');
    }
    if (!i.isButton()) return;
    const [prefix, action, channelId] = i.customId.split(':');
    if (prefix !== 'ticket') return;
    const t = getTicket(channelId);
    if (!t) return replyError(i, 'Ticket Not Found', 'This ticket record could not be found.');
    if (action === 'claim') return handleClaim(i, t);
    if (action === 'close') {
      if (t.status !== 'open') return replyError(i, 'Already Closed', 'This ticket is already closed.');
      if (i.user.id !== t.creatorId && !(await memberIsStaff(i.guild, i.user.id))) return replyError(i, 'No Permission', 'Only the ticket creator or staff can close this ticket.');
      return i.reply(payload([closeConfirmation(channelId)], true));
    }
    if (action === 'cancel-close') return i.update(payload([ok('Closure Cancelled', 'The ticket will remain open.')]));
    if (action === 'confirm-close') {
      if (busyTickets.has(channelId)) return replyError(i, 'Please Wait', 'This ticket is already being processed.');
      busyTickets.add(channelId);
      await i.update(payload([warn('Closing Ticket', 'Generating and archiving the transcript. Please wait...')]));
      try { return await closeTicket(i, t); } finally { busyTickets.delete(channelId); }
    }
    if (action === 'delete') {
      if (!(await memberIsStaff(i.guild, i.user.id))) return replyError(i, 'Staff Only', 'Only authorized staff can delete tickets.');
      if (t.status !== 'closed' || !t.transcriptArchived) return replyError(i, 'Cannot Delete', 'The ticket must be closed and its transcript archived first.');
      return i.reply(payload([deleteConfirmation(channelId)], true));
    }
    if (action === 'cancel-delete') return i.update(payload([ok('Deletion Cancelled', 'The ticket has not been deleted.')]));
    if (action === 'confirm-delete') {
      if (busyTickets.has(channelId)) return replyError(i, 'Please Wait', 'This ticket is already being processed.');
      busyTickets.add(channelId);
      await i.update(payload([warn('Deleting Ticket', 'The ticket channel is being permanently deleted...')]));
      try { return await deleteTicket(i, t); } finally { busyTickets.delete(channelId); }
    }
  } catch (e) {
    console.error('Interaction handler error:', e);
    try { await replyError(i, 'Something Went Wrong', `An error occurred while processing your request.\n\n**Details:** ${String(e.message || e).slice(0, 500)}`); } catch (_) {}
  }
});

// Startup recovery
async function recoverTickets() {
  const guild = await fetchGuild();
  for (const t of Object.values(db.tickets)) {
    if (t.status === 'deleted') continue;
    const channel = await guild.channels.fetch(t.channelId).catch(() => null);
    if (!channel) {
      const previous = t.status;
      t.channelMissing = true;
      if (t.status === 'open' || t.status === 'deleting') { t.status = 'deleted'; t.deletedAt = t.deletedAt || Date.now(); }
      else if (t.status === 'deleting') t.status = 'closed';
      saveDB();
      await logEvent('Ticket Channel Missing', `> **Ticket:** #${t.ticketNumber}\n> **Channel ID:** ${t.channelId}\n> **Previous Status:** ${previous}\n> **Note:** Channel was missing during startup recovery.`, CONFIG.colors.orange);
      continue;
    }
    t.channelMissing = false;
    if (t.status === 'deleting') { t.status = 'closed'; saveDB(); }
    if (t.closing && t.transcriptArchived) {
      t.status = 'closed'; t.closing = false; saveDB();
      try { await lockTicket(channel, t, guild); } catch (e) { console.error('Recovery lock failed:', e); }
    } else if (t.closing && !t.transcriptArchived) {
      t.closing = false; t.closedBy = null; t.closedAt = null; saveDB();
    }
    if (t.status === 'open' || t.status === 'closed') await updateTicketPanel(t);
  }
}

client.on(Events.MessageDelete, async message => {
  if (message.id !== db.dashboardMessageId || message.channelId !== CONFIG.dashboardChannelId) return;
  db.dashboardMessageId = null; saveDB();
  try { await ensureDashboard(); } catch (e) { console.error('Dashboard recreation failed:', e); }
});
client.on(Events.ChannelDelete, async channel => {
  const t = getTicket(channel.id);
  if (!t || t.status === 'deleted' || t.status === 'deleting') return;
  t.channelMissing = true; t.status = 'deleted'; t.deletedAt = Date.now(); saveDB();
  await logEvent('Ticket Channel Deleted', `> **Ticket:** #${t.ticketNumber}\n> **Channel ID:** ${channel.id}\n> **Note:** The channel was deleted outside the ticket delete button.`, CONFIG.colors.orange);
});

client.once(Events.ClientReady, async ready => {
  console.log(`Logged in as ${ready.user.tag}`);
  try {
    const guild = await fetchGuild();
    await fetchStaffRoles(guild);
    await registerCommands();
    await recoverTickets();
    await ensureDashboard();
    console.log('Las Vegas Roleplay Ticket System is ready.');
  } catch (e) { console.error('Ticket system startup error:', e); }
});

process.on('unhandledRejection', e => console.error('Unhandled promise rejection:', e));
process.on('uncaughtException', e => console.error('Uncaught exception:', e));
client.login(CONFIG.token);
