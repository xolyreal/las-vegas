LAS VEGAS ROLEPLAY TICKET BOT

FILES
- ticket-system.js: the bot script
- .env.example: template for your private environment file

SETUP
1. Install Node.js LTS.
2. Extract this ZIP into your project folder.
3. Rename .env.example to .env.
4. Put your bot token and application client ID in .env.
5. In the project folder, run:
   npm init -y
   npm install discord.js@14 dotenv
6. Start the bot:
   node ticket-system.js

IMPORTANT
- Do NOT share your .env file or bot token.
- The script uses ticket-state.json for saved ticket records. Keep that file when updating/restarting the bot.
- Check staffRoleIds near the top of ticket-system.js. Replace any role ID that does not exist in your server with the correct role ID.
- Enable Server Members Intent and Message Content Intent in the Discord Developer Portal.
- Ensure the bot has the required channel and message permissions in your server.
